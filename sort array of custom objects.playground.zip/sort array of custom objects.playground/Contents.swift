import Cocoa

//dictionary
var teamMembers = [13:"Mattias Janmark", 92:"Alex Nylander", 88:"Patrick Kane\n",7:"Brent Seabrook", 77:"Kirby Dach"]
var names = teamMembers[88]

//using arrays and control flow statements
var sum = 0
var sumB = 0
var average: Double = 0
var averageB: Double = 0
var ageOfPlayers = [22,27,33,25,37,32,21]
var heightOfPlayers = [72, 68, 73, 74, 71, 70, 71]
let birthdayMonths = ["January", "February", "February", "March", "April", "September", "November"]
let countedSet = NSCountedSet(array: birthdayMonths)
let mostFrequent = countedSet.max {countedSet.count(for: $0) < countedSet.count(for: $1)}
//NSCountedSet keeps track of num times objects are inserted. objects may appear more than once in the collection
ageOfPlayers.count
heightOfPlayers.count
for number in ageOfPlayers {
    sum += number
    average = (Double(sum)) / Double(ageOfPlayers.count)
}
for number in heightOfPlayers {
    sumB += number
    averageB = (Double(sumB)) / Double(heightOfPlayers.count)
}


print("The total number of players is", ageOfPlayers.count, "\n")
//print("The total age of the", ageOfPlayers.count, "players is", sum, "years")
print("The average age of the", ageOfPlayers.count, "players is", Float(average),"years\n")
print("The average height of the", heightOfPlayers.count, "players is", averageB, "inches\n")
print("The most common birthday month is", mostFrequent ?? <#default value#>,"\n\n\n")



//let birthdayMonths = ["January", "February", "March", "March"]
//let countedSet = NSCountedSet(array: birthdayMonths)
//let mostFrequent = countedSet.max {countedSet.count(for: $0) < countedSet.count(for: $1)}
//print("The most common birthday month is", mostFrequent ?? <#default value#>)


//need to sort Array of custom objects. created a custom swift class called "Player". i found out that if I follow the class approach and then print a swift class then i just get a generic lldb identifier...so had to follow struct approach, CustomStringConvertible and add a description property to make it print correctly.
struct Player : CustomStringConvertible {
    var description: String {
        return "Player \(name), age \(age), country \(country)"
    }
    
    let name : String
    let age : Int
    let country : String
    
}
var players:[Player] = []  //create an array that holds custom objects of type Player
let player1 = Player(name: "Pius Suter", age: 25, country: "Switzerland\n")
let player2 = Player(name: "Kirby Dach", age: 20, country: "Canada\n")
let player3 = Player(name: "Alex DeBrincat", age: 24, country: "United States\n")
let player4 = Player(name: "Mattias Janmark", age: 29, country: "Sweden\n")
let player5 = Player(name: "Dominik Kubalik", age: 26, country: "Czech Republic\n")



players.append(player1) //need to add the above elements to the array, var players
players.append(player2)
players.append(player3)
players.append(player4)
players.append(player5)

let sortedAge = players.sorted () { $0.age < $1.age }
let sortedCountry = players.sorted () { $0.country < $1.country }

print("The players, sorted by AGE are:\n\n",sortedAge,"\n\n")
print("The players, sorted by COUNTRY OF ORIGIN are:\n\n",sortedCountry)


