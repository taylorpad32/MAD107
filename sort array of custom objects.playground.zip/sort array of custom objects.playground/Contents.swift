import Cocoa

class Player {
    let name : String
    let age : Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}
var players:[Player] = []
let player1 = Player(name: "Billy", age: 30)
let player2 = Player(name: "Peter", age: 34)
let player3 = Player(name: "John", age: 20)

players.append(player1)
players.append(player2)
players.append(player3)


let sortedPlayers = players.sorted () { $0.age < $1.age }

print(sortedPlayers)

