import Cocoa
var spacer = 0
var clock = (hours: 00, minutes: 00, seconds: 00)
for _ in(0...8000000){
    spacer+=1
if(spacer == 750){
    spacer = 0
    clock.seconds += 1}
if(clock.seconds == 60){
    clock.seconds = 0
    clock.minutes += 1}
if(clock.minutes == 60){
    clock.hours += 1}
if(clock.hours == 13){
    clock.hours = 0}

print(clock)}


