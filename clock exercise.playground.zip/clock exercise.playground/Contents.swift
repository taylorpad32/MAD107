import Cocoa


//var str = "Hello, playground"
var clock = (hours: 00, minutes: 00, seconds: 00)

repeat {
    clock.seconds
} while clock.seconds <= 59
    clock.seconds += 1
    if clock.seconds == 60 {
        clock.minutes = 1
}

repeat {
    clock.minutes
} while clock.minutes <= 59
    clock.minutes += 1
    if clock.minutes == 60 {
        clock.hours = 1
}

repeat {
    clock.hours
} while clock.hours <= 12
    clock.hours += 1
    if clock.hours == 13 {
        clock.hours = 1
}

print(clock.hours, clock.minutes, clock.seconds)
