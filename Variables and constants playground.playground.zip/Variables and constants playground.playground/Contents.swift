import Cocoa

var currentLocation = "London"
currentLocation = "Crystal Lake"


var score = 0
score = 5
score = score + score

let whereIWasBorn = "Clitheroe England"
var whereILive = "Crystal Lake"
let myAge = "50"
var myFavoriteMovie = "The Usual Suspects"
let inchesInAFoot = "12"

score = 6
score += 2


let word1 = "Compound"
let word2 = "assignement"
let word3 = "is"
let word4 = "useful"
let space = " "

var statement = " "
statement += word1 + " " + word2 + " " + word3
    + " " + word4


let scoreForGreen = 5
let scoreForRed = 10
let scoreForGold = 20

var scoreForGary = 0
var scoreForRob = 0

scoreForGary += scoreForRed
scoreForGary += scoreForGreen
scoreForGary += scoreForGold

scoreForRob += scoreForRed
scoreForRob += scoreForGreen
scoreForRob += scoreForGold


// shopping list
var Statement = " "
let eggs = "Eggs"
let milk = "Milk"
let cheese = "Cheese"
let bread = "Bread"
let rice = "Rice"
let newline = "\n"

Statement +=  eggs + newline + eggs + ", " + milk + newline + eggs + ", " + milk
    + ", " + rice + newline
print(Statement)

let darts: Int = 501
var round: Int = 0
var outcome = 0
print("You have 3 darts, and 4 rounds to score 501; let's go!")
print(" ")
print("What is yout total of the 3 darts, after the round?")
round = 6
print(round)
var results = (darts - round)
print("After Round 1 you need", results, "to win")
print(" ")
if results < 321 {
    print("That's fantastic, are you ready for round 2?")
}
print(" ")
print("What's your total of the 3 darts after round 2?")
round = 5
print(round)
round - results
//print(" ")
results = (results - round)
print("After Round 2 you need", results, "to win")
if results < 141 {
    print("That's fantastic, are you ready for round 3?")
}
print(" ")
print("What's your total of the 3 darts after round 3?")
round = 10
print(round)
round - results
//print(" ")
results = (results - round)
print("After Round 3 you need", results, "to win")
if results == 0 {
    print("That's fantastic, you are a winner?")
}
print(" ")
print("What's your total of the 3 darts after round 4?")
round = 10
print(round)
round - results
//print(" ")
results = (results - round)
outcome = darts - results
print("After Round 4 you have scored", outcome)
if results == 0 {
    print("That's fantastic, you are a winner?")
}
















