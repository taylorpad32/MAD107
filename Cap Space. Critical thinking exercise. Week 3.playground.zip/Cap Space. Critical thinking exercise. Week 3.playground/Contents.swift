import Cocoa

var str = " "
print("Good morning. You have been given a Cap of $20,000,000, for 3 players")
print( " ")
print("The 3 players are: Frederick Anderson (G), Thomas Chabot (D) and Brock Boeser (F).")
print("To be successful, the salary of D > G, F > D, and the combined 3 salaries must be <= $20,000,000")
print(" ")
let cap = 20000000
var g: Double = 2000000
var d: Double = 8000000
var f: Int = 9500000
var total = Double(f) + g + d
let percent = 100
var capSpace = Int((total) / Double(cap) * Double(percent))
print("Your salary total is", "$", total)

print(" ")
if Int(total) < cap, d > g, f > Int(d) {
print("Congratulations! You are $", (cap - Int(total)), "under the Cap. You have used", capSpace,"% of the cap")
} else if Int(total) > cap {
print("You have exceeded the cap. Please rememember that the cap is $20,000,000 for all 3 player combined ")
} else if Int(total) < cap, d < g {
print("Even though you are under the cap, these salary choices cannot be accepted. Please remember that D > G and F > D")
} else if Int(total) < cap, f < Int(d) {
print("Even though you are under the cap, these salary choices cannot be accepted. Please remember that D > G and F > D")
}



