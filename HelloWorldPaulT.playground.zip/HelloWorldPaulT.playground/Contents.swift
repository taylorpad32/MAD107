import Cocoa

print("Hello, World")
