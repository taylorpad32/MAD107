
import Foundation

import UIKit

import UIKit


//var contacts = ["Sally James":(212,555,1212)] //, //"Venus":415_222_1212]
//var people = contacts["Sally James"]
//print(people ?? <#default value#>)

//======================================

var contact = ["Peter Pan":(501,202,3214), "Nicholas Taylor":(415,333,3212),"Neo":(212,324,3571),"Mr Anderson":(212,760,1745),"Leon Draisaitl":(780,122,4930)]
//var names = contact["Peter Pan"]
//print(names ?? <#default value#>)

struct Contacts : CustomStringConvertible {
    var description: String {
       return " \(name), \(phone_number)"
    }
    
    let name : String
    let phone_number : (Int, Int, Int)
    
    
}
var contacts:[Contacts] = []  //create an array that holds custom objects of type Player
let contacts1 = Contacts(name: "\nPeter Pan", phone_number: (501,202,3214)) //this is a tuple. think of it as an array with a mix of int and string. put the tuple inside the array.
let contacts2 = Contacts(name: "\nNicholas Taylor", phone_number: (415,333,3212))
let contacts3 = Contacts(name: "\nNeo", phone_number: (212,324,3571))
let contacts4 = Contacts(name: "\nMr Anderson", phone_number: (212,760,1745))
let contacts5 = Contacts(name: "\nLeon Draisaitl", phone_number: (780,122,4930))

contacts.append(contacts1) //need to add the above elements to the array, var players
contacts.append(contacts2)
contacts.append(contacts3)
contacts.append(contacts4)
contacts.append(contacts5)

let sortedName = contacts.sorted () { $0.name < $1.name }

print("My friends, sorted by First Name are:\n\n",sortedName)

var names = contact["Neo"]
print("\nMy friend's phone number is:\n")

print(names ?? <#default value#>)

print("\nPlease click on 'Next', immediately below in blue, to search for information on Clubs and Groups." )
//: [Next](@next)
