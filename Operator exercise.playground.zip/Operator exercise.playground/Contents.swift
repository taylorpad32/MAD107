import Cocoa

print("Good morning. \nThe following is a calculator programme, that has been designed to make 5 simple calculations:\n \nAddition/Subtraction/Division/Percentages/Remainder.\n\n")
print("Subsequently, the calculator programme will address Precedence and Associativity.\n")
print("To end, the calculator will add together 2 Vectors.\n\nLet's begin!")
var a = 2
var b = 5
var c = 7
var d = 12
let percent = 100

let pA = CGPoint(x: 2, y: 3)
let pB = CGPoint(x: 7, y: 8)
let vecAB = CGVector(dx: pB.x + pA.x, dy: pB.y + pA.y)

var addition = a + b
var subtraction = d - c
var division: Double = Double(d) / Double(b)
var per = Double(a) / Double(b) * Double(percent)
var remainder = d % c
var precede = a + c % b * d
print(" \n")
print("Addition result is:", addition)
print("Subtraction result is:", subtraction)
print("Division result is:", division)
print("Percent result is:", per)
print("Remainder result is:", remainder, "\n")
print("Precendence result is:", precede, "\n")
print("Vector addition result is:", vecAB)





