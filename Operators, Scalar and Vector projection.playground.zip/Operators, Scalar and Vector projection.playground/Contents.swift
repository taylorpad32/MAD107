import Cocoa

print("Hi there.\n\nThis programme is going to discuss Scalar and Vector projection,\nand how they apply to real world situations.\n")

print("Scalar (shadow) projection is the length of a vector, projected\non another vector.\n")
print("Vector projection is when we add direction onto the length.\n\n")

print("Let's calculate Scalar and Vector projection of vector a = [1, 2] onto b = [3, 4]\n")

var pA = CGPoint(x: 1, y: 2)
var pB = CGPoint(x: 1, y: 1)
let vecAB = (pA.x * pB.x)  //3
let vecCD = (pA.y * pB.y)  //8
let vecEF = (vecAB + vecCD) //11
let vecGH = pow(pB.x,2) + pow(pB.y,2)  //25
let vecIJ = (vecEF/vecGH)  //0.44
let vecMN = CGVector(dx: pB.x * vecIJ, dy: pB.y * vecIJ) // vector projection
let vecOP = sqrt(vecGH) // 5  vector maginitude
let vecQR = vecEF/vecOP // scalar projection

print("The Scalar Projection is",vecQR)
print("The Vector Projection is",vecMN, "\n")

print("How do we apply this to real world?\n")
print("Consider #1:\nA ball travels with velocity given by [2 1],\nwith wind blowing in the direction given by [3 -4].\n\nWhat is the size (length) of the velocity of the ball in the direction of the wind?")
print("This is a SCALAR PROJECTION of the velocity of the ball onto the velocity of the wind\n")
print("On line 10, please enter 2 as the x input, and 1 as the y input")
print("On line 11, please enter 3 as the x input, and -4 as the y input\n")
print("The Scalar projection is", vecQR,"\n\n")

    
print("Consider #2:\nA ship travels with velocity give by [1 2],\nwith current flowing in the direction given by [1 1],\n")
print("What is the velocity of the ship in the direction of the current?")
print("This is a VECTOR PROJECTION of the velocity of the ship onto the velocity of the current\n")
print("On line 10, please enter 1 as the x input, and 2 as the y input")
print("On line 11, please enter 1 as the x input, and 1 as the y input\n")
print("The Vector projection is", vecMN)







